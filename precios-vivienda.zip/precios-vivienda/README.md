precios_vivienda
------------


![alt text](https://badgen.net/badge/python/3.10.12/cyan?icon=pypi)


## Description
# Análisis de Datos del IPV

Este proyecto proporciona un conjunto de clases para cargar, limpiar y analizar datos sobre el índice de precios de vivienda (IPV) por comunidad autónoma en España. Los datos provienen de un archivo CSV de la pagina del INE y las clases permiten calcular diferentes métricas como el índice actual, la variación anual, trimestral y desde 2015 para cada comunidad.

## Descripción

El proyecto está compuesto por tres clases principales:

- **IPVDataLoader**: Carga y limpia los datos desde un archivo CSV.
- **ComunidadIPV**: Representa una comunidad autónoma y permite calcular métricas como el índice actual y las variaciones de precios en diferentes periodos.
- **IPVAnalyzer**: Analiza todos los datos y genera un resumen con las métricas calculadas para cada comunidad, además de un ranking por crecimiento.

## Requisitos

-Pandas version 2.2.2
-Matplotlib.pyplot 3.8.0

Puedes instalar las dependencias utilizando `pip`:

```bash
pip install pandas
pip install matplotlib.pylot
### Owner
-Elisa Cisneros Espinoza <elisacisnerose@gmail.com>