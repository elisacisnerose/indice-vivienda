"""Top-level package for package_name."""

__author__ = "Elisa Cisneros Espinoza"
__email__ = "elisacisnerose@gmail.com"
__version__ = "0.0.2"

PACKAGE_NAME = "precios_vivienda"