import pandas as pd
import matplotlib.pyplot as plt
from precios_vivienda import ComunidadIPV

def __init__(self, df):
    self.df = df
    self.comunidades = self._crear_comunidades()


def _crear_comunidades(self):
    comunidades = {}
    df_com = self.df[self.df['Comunidades y Ciudades Autónomas'].notna()]
    for comunidad in df_com['Comunidades y Ciudades Autónomas'].unique():
        datos_com = df_com[df_com['Comunidades y Ciudades Autónomas'] == comunidad]
        comunidades[comunidad] = ComunidadIPV(comunidad, datos_com)
    return comunidades


def resumen_total(self):
    metricas = [comunidad.calcular_metricas() for comunidad in self.comunidades.values()]
    return pd.DataFrame(metricas).sort_values(by='Índice Actual', ascending=False)


def ranking_crecimiento(self):
    resumen = self.resumen_total()
    return resumen.sort_values(by='Variación Anual (%)', ascending=False)