import pandas as pd


def __init__(self, file_path):
    self.file_path = file_path


def load_data(self):
    df=pd.read_csv(self.file_path, sep='\t', encoding='utf-8')
    df['Total'] = df['Total'].str.replace(',', '.').astype(float)
    df = df.dropna(subset=['Total', 'Periodo'])
    df = df.reset_index(drop=True)

    return df
