def __init__(self, nombre, datos):
    self.nombre = nombre
    self.datos = datos.sort_values('Periodo')


def indice_actual(self):
    return self.datos.iloc[-1]['Total']


def variacion_anual(self):
    if len(self.datos) < 5:
        return None
    return ((self.datos.iloc[-1]['Total'] / self.datos.iloc[-5]['Total']) - 1) * 100


def variacion_trimestral(self):
    if len(self.datos) < 2:
        return None
    return ((self.datos.iloc[-1]['Total'] / self.datos.iloc[-2]['Total']) - 1) * 100


def variacion_desde_2015(self):
    base = self.datos[self.datos['Periodo'].str.contains('2015')]
    if not base.empty:
        return ((self.datos.iloc[-1]['Total'] / base.iloc[0]['Total']) - 1) * 100
    else:
        return None


def calcular_metricas(self):
    return {
        'Comunidad': self.nombre,
        'Índice Actual': self.indice_actual(),
        'Variación Anual (%)': self.variacion_anual(),
        'Variación Trimestral (%)': self.variacion_trimestral(),
        'Variación Desde 2015 (%)': self.variacion_desde_2015()
    }