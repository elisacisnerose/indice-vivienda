"""Main module."""
import pandas as pd
from precios_vivienda import IPVDataLoader

def main():
    file_path = 'data/25171.csv'


    print("Datos cargados correctamente:")


if __name__ == '__main__':
    main()
